<?php

$a = bin2hex("Hello World");
echo $a;

?>