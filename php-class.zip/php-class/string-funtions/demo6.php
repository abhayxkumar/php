<?php

$a = "Hello World";
echo chunk_split($a, 1, '-');

?>