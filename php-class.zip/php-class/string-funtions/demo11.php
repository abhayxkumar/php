<?php
$str = "Hello world!";
print_r (explode(" ", $str));
?>