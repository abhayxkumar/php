<?php

$a = addslashes('Hello"World"');
echo($a);

?>