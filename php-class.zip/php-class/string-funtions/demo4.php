<?php

$a = chop("Hello World", "World");
echo $a;


?>