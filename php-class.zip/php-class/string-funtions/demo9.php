<?php

$a = "Hello World";
echo count_chars($a, 4); //unused characters

echo count_chars($a, 3); //used characters


?>