<?php

$a = ",2&5L;&\@=V]R;&0A `";
echo convert_uudecode($a);

?>