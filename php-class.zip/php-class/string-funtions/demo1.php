<?php

$a = addcslashes("Abhay", "A");
echo $a;

?>