<?php

echo chr(72);

?>