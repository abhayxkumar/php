<?php

$a = "Hello World";
echo crypt($a, "Abhay");

?>