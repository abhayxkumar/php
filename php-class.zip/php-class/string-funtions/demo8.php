<?php

$a = "Hello World!";
echo convert_uuencode($a);

?>