<?php
$var=-45;
$num=45.8;
$id=true;
var_dump($id);